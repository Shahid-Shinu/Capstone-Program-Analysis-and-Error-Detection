#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
	Node *p=malloc(sizeof(Node));
	p=list->head;
	Node *temp=malloc(sizeof(Node));
	temp->data=data;
	if(p == NULL)
	{
		list->head=temp;
		return;
	}
	else
	{
		p=list->head;
		while(p->link!=NULL)
		{
			p=p->link;
		}
		p->link=temp;
	}
	temp=NULL;
	free(temp);
	list->number_of_nodes+=1;
}

void list_delete_front(List* list) {
	Node *p=malloc(sizeof(Node));
	p=list->head;
	Node *delNode=malloc(sizeof(Node));
	if(p == NULL)
	{
		return;
	}
	else
	{
		delNode=list->head;
		list->head=list->head->link;
	}
	delNode=NULL;
	free(delNode);
	list->number_of_nodes-=1;
}

void list_insert_at (List *list, int data, int position)
{
	Node *p=malloc(sizeof(Node));
	p=list->head;
	Node *temp=malloc(sizeof(Node));
	temp->data=data;
	if(p == NULL)
	{
		return;
	}
	else
	{
		for(int i =0; i < position;i++)
		{
			p=p->link;
		}
		temp->link=p;
		p->link=temp;
		
	}
	free(temp);
	list->number_of_nodes+=1;
}

void list_reverse(List* list)
{
 	Node *p=malloc(sizeof(Node));
	p=list->head;
	Node *temp=malloc(sizeof(Node));
	if(p == NULL)
	{
		return;
	}
	else
	{	
		temp=list->head->link;
		list->head=list->head->link;
		p->link=NULL;
		while(list->head!=NULL)
		{
			list->head=list->head->link;
			temp->link=p;
			p=temp;
			temp=list->head;

		}
		list->head=p;
	}
}
