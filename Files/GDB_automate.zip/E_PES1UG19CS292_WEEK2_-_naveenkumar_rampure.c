#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
	Node *temp ,*p;
	temp=(Node*)malloc(sizeof(Node));
	temp->data=data;
	temp->link=NULL;
	p=list->head;
	if(p==NULL)
	{
	list->head=temp;
	}
	else{
	while(p->link!=NULL)
	{
	p=p->link;
	}
	p->link=temp;
	}
	
}

void list_delete_front(List* list) {
	Node *p=list->head;
	//if(list->head==NULL)
	//return 0;
	list->head=p->link;
	free(p);
	
}

void list_insert_at (List *list, int data, int position)
{
	
	Node*p=list->head;
	for(int i=0;i<position;i++)
	{
	p=p->link;
	}
	Node*temp;
	temp=(Node*)malloc(sizeof(Node));
	temp->data=data;
	temp->link=p->link;
	p->link=temp;
}
void list_reverse(List* list)
{
 	Node *previous =NULL;
 	Node *pp= list->head;
 	Node *temp=NULL;
 	
 	
 	while(pp!=NULL)
 	{
 	temp=pp->link;
 	pp->link=previous;
 	previous=pp;
 	pp=temp;
 	
 	}
 	list->head=previous;
 	
 }



