#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
    Node *p=(Node*)malloc(sizeof(Node));
    p=(list->head);
    while (p != NULL)
        p = p->link;
    p->link = NULL;
    (p->data)=data;
    (list->number_of_nodes)++;
}

void list_delete_front(List* list) {
    if(list->head!=NULL)
	{
        list->head = list->head->link;
        (list->number_of_nodes)--;
    }
}

void list_insert_at (List *list, int data, int position)
{
    int i=1;
    Node *p;
	Node *new_node;
    new_node->data=data;
    new_node->link=NULL;
    p= list->head;
    while (p != NULL && i != position)
    {
        p = p->link;
        i++;
    }
    if(i!=list->number_of_nodes)
    {
        new_node->link = p->link;
    }
    p->link = new_node;
    (list->number_of_nodes)++;
}

void list_reverse(List* list)
{
 	List *new_list=list_initialize();
    Node *p;
    p=list->head;
    while(p != NULL)
    {
        list_insert_at(new_list, p->data, 0);  
        p=p->link;
    }
    list=new_list;
    list_destroy(new_list);
}


