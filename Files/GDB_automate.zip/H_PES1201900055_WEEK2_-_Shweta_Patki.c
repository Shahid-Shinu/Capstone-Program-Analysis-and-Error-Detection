#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
	Node *p = malloc(sizeof(Node));
	p->data = data;
	p->link = NULL;
	Node *temp = list->head;
	if (list->head == NULL) 
	{
		list->head = p;
	}
	else 
	{
		struct Node* temp = list->head;
		while (temp->link != NULL) 
		{
			temp = temp->link;
		}
		temp->link = p;
	}
	(list->number_of_nodes)++;
	return;
}

void list_delete_front(List* list) {
	Node *temp = list->head;
	if (temp->link==NULL)
	{
		return;
	}
	list->head = list->head->link;
	free(temp);
	(list->number_of_nodes)--;
	return;
}

void list_insert_at (List *list, int data, int position)
{
	struct Node *p = malloc(sizeof(struct Node));
	p->data = data;
	if (position <= 0) 
	{
		p->link = list->head;
		list->head = p;
		return;
	}
	else if (position <= list->number_of_nodes) 
	{
		Node *temp = list->head;
		for (int i = -1; i <= position; i++) 
		{
			if (i == position) 
			{
				p->link = temp->link;
				temp->link = p;
			}
			temp = temp->link;
		}	
	}
	else
	{
		insert_at_end(list, data);
	}
	(list->number_of_nodes)++;
	return;
}

void list_reverse(List* list)
{
	Node* last = NULL; 
  Node* now = list->head; 
  Node* next = NULL; 
  while (now != NULL) 
	{
		next = now->link; 
    now->link = last; 
    last = now; 
    now = next; 
  } 
  list->head = last; 
 	return;
}