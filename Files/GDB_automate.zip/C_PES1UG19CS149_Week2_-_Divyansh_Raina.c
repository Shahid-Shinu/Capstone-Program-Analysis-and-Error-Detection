#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
	//TODO
	Node *ptr,*new_node;
	new_node=(Node *)malloc(sizeof(Node));
	new_node->data = data;
	new_node->link = NULL;
	ptr=list->head;
	if(ptr==NULL){
        ptr=new_node;
        list->head=ptr;
	}
	else{while(ptr->link != NULL){
        ptr=ptr->link;
	}
	ptr->link=new_node;}
}

void list_delete_front(List* list) {
	//TODO

		Node *ptr;
	ptr=list->head;
	if(ptr->link==NULL){
	    free(ptr);
	}
	else{
	    Node *next;
	    next=ptr->link;
	    list->head=next;
	    free(ptr);
	    list->number_of_nodes -=1;

	}
}

void list_insert_at (List *list, int data, int position)
{
	//TODO
		Node *ptr,*new_node,*preptr;
	new_node=(Node *)malloc(sizeof(Node));
	new_node->data = data;
	new_node->link = NULL;
	ptr=list->head;


	if(position==0){
	    new_node->link=ptr;
	    ptr=new_node;
	    return;
	}
	for(int i=0;i<position;i++){
	    ptr=ptr->link;
	}
    new_node->link=ptr->link;
    ptr->link = new_node;
    list->number_of_nodes +=1;

	}

void list_reverse(List* list)
{
 	//TODO
 		Node *rev,*ptr,*next;
 	next=NULL;
 	rev=NULL;
 	ptr=list->head;
 	while(ptr!=NULL)
 	{
 	    next=ptr->link;
 	    ptr->link=rev;
 	    rev=ptr;
 	    ptr=next;
 	}
 	list->head=rev;

}


