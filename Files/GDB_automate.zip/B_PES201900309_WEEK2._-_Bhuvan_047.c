#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) 
{
	Node *new = (Node *)malloc(sizeof(Node));
	new->link = NULL;
	new->data = data;
	if (list->head == NULL)
	{
		list->head = new;
	}
	else
	{
		Node *temp = list->head;
		while(temp->link != NULL)
		{
			temp = temp->link;
		}
		temp->link = new;
		
	}
	list->number_of_nodes += 1;
}

void list_delete_front(List* list) 
{
	if (list->head == NULL)
	{
		return;
	}
	else if (list->head->link == NULL)
	{
		Node *temp = list->head;
		list->head = NULL;
		list->number_of_nodes -= 1;
		free(temp);
	}
	else
	{
		Node *temp = list->head;
		list->head = list->head->link;
		list->number_of_nodes -= 1;
		free(temp);
	}
	
	
}

void list_insert_at(List *list, int data, int position)
{
	int pos = 0;
	Node *new = (Node *)malloc(sizeof(Node));
	new->data = data;
	if(position==0)
	{
		new->link = list->head;
		list->head = new;
		list->number_of_nodes += 1;
	}
	else if( position>0 && position < (list->number_of_nodes))
	{
		Node *temp = list->head;
		while(pos<position-1)
		{
			temp = temp->link;
			pos += 1;
		}
		new->link = temp->link;
		temp->link = new;
		list->number_of_nodes += 1;

	}
	
}

void list_reverse(List* list)
{
	int n,tmp;
    n = list->number_of_nodes;
    Node *temp1 = list->head;

    for(int i=0; i<n/2; i++)
    {
        Node *temp2 = list->head;
        for(int j=0; j<n-i-1; j++)
            temp2 = temp2->link;

        tmp = temp1->data;
        temp1->data = temp2->data;
        temp2->data = tmp;

        temp1 = temp1->link;


    }
 	
}


