#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
	//TODO
	
	Node *temp;
    temp=(Node*)malloc(sizeof(Node));
    temp->data=data;
    temp->link=NULL;

    if(list->head==NULL)
        list->head=temp;
        else
        {
            Node* cur=list->head;
            while(cur->link!=NULL)
                cur=cur->link;
            cur->link=temp; 
        }   
    list->number_of_nodes++;

}

void list_delete_front(List* list) {
	//TODO
	Node *temp;
    temp=list->head;
    list->head=temp->link;
    free(temp);
}

void list_insert_at (List *list, int data, int position)
{
	//TODO
	Node *pre,*temp,*curr;
    int i=1;
    pre=NULL;
    curr=list->head;

    temp=(Node *)malloc(sizeof(Node));
    temp->data=data;
    temp->link=NULL;

    while((curr!=NULL)&&(i<position))
    {
        pre=curr;
        curr=curr->link;
        i++;
    }
    if(curr!=NULL)
    {
        if(pre==NULL)
        {
            temp->link=list->head;
            list->head=temp;
        }
        else
        {
            pre->link=temp;
            temp->link=curr;
        }   
    }
    else
    {
        if(i==position)
            pre->link=temp;
        else
            printf("Invalid Position");
    }
	

}

void list_reverse(List* list)
{
 	//TODO
	
	Node *pre,*temp,*curr;
    pre=NULL;
    curr=list->head;

    while(curr!=NULL)
    {
        temp=curr->link;
        curr->link=pre;
        pre=curr;
        curr=temp;
    }

    list->head=pre;
}


