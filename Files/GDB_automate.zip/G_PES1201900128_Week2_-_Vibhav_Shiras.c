#include<stdio.h>
#include<stdlib.h>
#include "sll.h"

void insert_at_end(List *list, int data) {
	//TODO
	struct Node *temp,*ptr1;
	
	temp=(struct Node*)malloc(sizeof(struct Node));
	temp->data=data;
	temp->link=NULL;
	
	if(list->head==NULL)//is the list empty
	   list->head=temp;
	   else
	   {
		ptr1=list->head;
		while(ptr1->link!=NULL)
		  ptr1=ptr1->link;
		ptr1->link=temp;      
	    }
	
}

void list_delete_front(List* list) {
	//TODO
	struct Node *ptr;
	
	ptr=list->head; 
	list->head=ptr->link;  
	free(ptr);
}

void list_insert_at (List *list, int data, int position)
{
	//TODO
	struct Node *prev,*temp,*ptr;
	
	int i=1;
	prev=NULL;
	
	ptr=list->head;
	
	//create a node
	
	temp=(struct Node*)malloc(sizeof(struct Node));
	temp->data=data;
	temp->link=NULL;
	
	
	//move forward until the position is found
	while((ptr!=NULL)&&(i<position))
	{
		prev=ptr;
		ptr=ptr->link;
		i++;
	}
	
	if(ptr!=NULL) 
	{
	   if(prev==NULL) 
	    {
		temp->link=list->head;
		list->head=temp;
	    }
	    else
	    {
		prev->link=temp; 
		temp->link=ptr;
	    }
	}
       else 
        {
	   if(i==position) 
	     prev->link=temp;
	   else
	     printf("Invalid Position");
        }
	

}

void list_reverse(List* list)
{
 	//TODO
	struct Node *ptr1, *ptr2, *ptr3;
	ptr1=NULL;
	
	ptr3=list->head;
	
	while(ptr3!=NULL)
	{
		ptr2=ptr3->link;
		ptr3->link=ptr1;
		ptr1=ptr3;
		ptr3=ptr2;
	}
	
	 list->head=ptr1;

}